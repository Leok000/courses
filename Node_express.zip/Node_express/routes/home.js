const {Router} = require('express');
const router = Router();

router.get('/', (req, res) => {
    res.render('index', {
        title: 'Main Page',
        isHome: true
    })
/* ====  res.status(200)
    res.sendFile(path.join(__dirname, 'views', 'insex.html')) */
}) // method get


module.exports = router